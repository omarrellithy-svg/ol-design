// مهم: اكتب رقم واتساب بصيغة دولية من غير + أو مسافات أو شرطات.
// مثال لمصر: 2010XXXXXXX (استبدل X بأرقامك الحقيقية).
const WHATSAPP_NUMBER = "201022405158";

const menuToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");

menuToggle?.addEventListener("click", () => {
  const isOpen = mainNav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.setAttribute("aria-label", isOpen ? "إغلاق القائمة" : "فتح القائمة");
});

mainNav?.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    mainNav.classList.remove("open");
    menuToggle?.setAttribute("aria-expanded", "false");
  });
});

document.getElementById("year").textContent = new Date().getFullYear();

function openWhatsApp(message) {
  if (!/^\d{10,15}$/.test(WHATSAPP_NUMBER)) {
    alert("رقم واتساب غير مضبوط. راجع الرقم في ملف script.js.");
    return;
  }
  const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
  window.open(url, "_blank", "noopener,noreferrer");
}

document.getElementById("whatsappLink")?.addEventListener("click", (event) => {
  event.preventDefault();
  openWhatsApp("أهلًا OL Design، عايز أستفسر عن خدمات التصميم.");
});

document.querySelectorAll("[data-service]").forEach((link) => {
  link.addEventListener("click", () => {
    const serviceSelect = document.getElementById("service");
    const wanted = link.dataset.service;
    if (serviceSelect && [...serviceSelect.options].some(option => option.value === wanted || option.text === wanted)) {
      serviceSelect.value = wanted;
    }
  });
});

document.getElementById("orderForm")?.addEventListener("submit", (event) => {
  event.preventDefault();
  const name = document.getElementById("customerName").value.trim();
  const service = document.getElementById("service").value;
  const details = document.getElementById("details").value.trim();
  const budget = document.getElementById("budget").value.trim();

  if (!name || !service || !details) {
    alert("من فضلك املأ الاسم والخدمة وتفاصيل الطلب.");
    return;
  }

  const message = [
    "أهلًا OL Design، عندي طلب تصميم جديد.",
    `الاسم: ${name}`,
    `الخدمة: ${service}`,
    `تفاصيل الطلب: ${details}`,
    budget ? `الميزانية: ${budget}` : ""
  ].filter(Boolean).join("\n");

  openWhatsApp(message);
});


// مساعد OL Design: ردود جاهزة محفوظة داخل ملفات الموقع.
const chatToggle = document.getElementById("chatToggle");
const chatPanel = document.getElementById("chatPanel");
const chatClose = document.getElementById("chatClose");
const chatForm = document.getElementById("chatForm");
const chatInput = document.getElementById("chatInput");
const chatMessages = document.getElementById("chatMessages");

function addChatMessage(text, who) {
  const bubble = document.createElement("div");
  bubble.className = who === "user" ? "user-message" : "bot-message";
  bubble.textContent = text;
  chatMessages.appendChild(bubble);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}
function getBotReply(message) {
  const q = message.toLowerCase().replace(/[أإآ]/g, "ا").replace(/ة/g, "ه");
  if (/سعر|اسعار|بكام|تكلفه|التكلفه|جنيه/.test(q)) return "الأسعار الاسترشادية الموجودة بالموقع:\n• تصميم أساسي: 250 جنيه\n• تصميم مميز: 450 جنيه\n• باقة مشروع: 750 جنيه\nالسعر النهائي بيتحدد حسب تفاصيل الطلب والتعديلات المطلوبة.";
  if (/لوجو|شعار/.test(q)) return "بنقدم تصميم شعارات وهوية بصرية. ابعتلنا اسم المشروع وفكرته والألوان اللي بتحبها، وهنحدد السعر والمدة حسب التفاصيل.";
  if (/منيو|مطعم|كافيه|كافيه/.test(q)) return "أيوه، بنصمم منيوهات للمطاعم والكافيهات. جهّز أسماء الأصناف والأسعار والمقاس، وابعت التفاصيل على واتساب.";
  if (/يافطه|يفطه|لافت|محل/.test(q)) return "بنساعدك في تصميم يافطات المحلات. ابعت اسم المحل والمقاس التقريبي والألوان أو صورة مرجعية لو موجودة.";
  if (/اعلان|سوشيال|فيس|انستجرام/.test(q)) return "بنصمم إعلانات وتصميمات سوشيال ميديا. قولنا نوع النشاط وهدف الإعلان والمقاس والمنصة.";
  if (/كارت|بطاقه شخصيه/.test(q)) return "متاح تصميم كروت شخصية. ابعت الاسم والمسمى الوظيفي ورقم التواصل وأي بيانات تحب تظهر.";
  if (/اطلب|طلب|اتواصل|واتساب|رقم|تليفون|هاتف/.test(q)) return "تقدر تطلب مباشرة على واتساب من الرقم 01022405158، أو تملأ نموذج الطلب الموجود في قسم «اطلب تصميمك» بالموقع.";
  if (/مده|وقت|امتى|تسليم/.test(q)) return "مدة التنفيذ بتختلف حسب نوع التصميم والتفاصيل والتعديلات. ابعتلنا تفاصيل طلبك عشان نحدد لك المدة المناسبة.";
  if (/خدمات|بتعملوا|بتقدموا|ايه بت/.test(q)) return "خدماتنا تشمل: تصميم الشعارات، يافطات المحلات، منيوهات المطاعم، إعلانات السوشيال ميديا، الكروت الشخصية وباقات تصميم للمشروعات.";
  if (/اهلا|السلام|مرحبا|هاي|hello/.test(q)) return "أهلًا وسهلًا بيك في OL Design 👋 تحت أمرك! اسألني عن الأسعار أو الخدمات أو طريقة الطلب.";
  return "شكرًا لسؤالك ❤️ ممكن توضح نوع التصميم اللي محتاجه؟ خدماتنا تشمل اللوجوهات والمنيوهات واليافطات وإعلانات السوشيال ميديا والكروت الشخصية. وللاستفسار المباشر واتساب: 01022405158";
}
chatToggle?.addEventListener("click", () => {
  const opening = chatPanel.hidden;
  chatPanel.hidden = !opening;
  chatToggle.setAttribute("aria-expanded", String(opening));
  if (opening) chatInput?.focus();
});
chatClose?.addEventListener("click", () => {
  chatPanel.hidden = true;
  chatToggle?.setAttribute("aria-expanded", "false");
});
chatForm?.addEventListener("submit", (event) => {
  event.preventDefault();
  const message = chatInput.value.trim();
  if (!message) return;
  addChatMessage(message, "user");
  addChatMessage(getBotReply(message), "bot");
  chatInput.value = "";
  chatInput.focus();
});
